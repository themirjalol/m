from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
import subprocess

app = FastAPI()

html = """
<form method="post">
    <button name="action" value="start">✅ START BOT</button>
    <button name="action" value="stop">⛔ STOP BOT</button>
</form>
"""

@app.get("/", response_class=HTMLResponse)
async def index():
    return html

@app.post("/", response_class=HTMLResponse)
async def control(action: str = Form(...)):
    if action == "start":
        with open("bot_status.txt", "w") as f:
            f.write("on")
        subprocess.Popen(["python", "bot.py"])
        return html + "<p style='color:green;'>✅ Bot ishga tushdi</p>"
    elif action == "stop":
        with open("bot_status.txt", "w") as f:
            f.write("off")
        subprocess.run(["pkill", "-f", "bot.py"])
        return html + "<p style='color:red;'>⛔ Bot to‘xtadi</p>"
    return html