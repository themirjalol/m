from aiogram import Bot, Dispatcher, types
import asyncio

TOKEN = "YOUR_BOT_TOKEN"

async def main():
    with open("bot_status.txt", "r") as f:
        status = f.read().strip()
    if status != "on":
        print("Bot holati: OFF. Ishga tushmaydi.")
        return

    bot = Bot(token=TOKEN)
    dp = Dispatcher()

    @dp.message()
    async def echo_handler(message: types.Message):
        await message.reply("✅ Bot ishlayapti!")

    print("Bot ishga tushdi...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())